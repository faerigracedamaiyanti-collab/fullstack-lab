const express = require("express");
const app = express();

const errorHandler = require("./middleware/errorHandler");

// middleware bawaan express (JSON parser)
app.use(express.json());

// ✅ SUCCESS ROUTE
app.get("/success", (req, res) => {
  res.json({
    success: true,
    message: "This is a success response 🚀",
  });
});

// HOME ROUTE
app.get("/", (req, res) => {
  res.send("Server is running 🚀");
});

// ❌ ERROR ROUTE (manual throw error)
app.get("/error", (req, res) => {
  throw new Error("Something went wrong");
});

// ❌ CUSTOM ERROR ROUTE (Step 4 requirement)
app.get("/user", (req, res) => {
  const user = null;

  if (!user) {
    throw new Error("User not found");
  }

  res.json(user);
});

// ❗ ERROR MIDDLEWARE (WAJIB PALING BAWAH)
app.use(errorHandler);

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});