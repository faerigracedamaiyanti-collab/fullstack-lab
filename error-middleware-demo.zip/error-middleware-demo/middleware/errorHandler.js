function errorHandler(err, req, res, next) {
  // log error di server
  console.error("Error:", err.message);

  // structured error response (sesuai soal)
  res.status(500).json({
    success: false,
    message: err.message || "Something went wrong",
  });
}

module.exports = errorHandler;