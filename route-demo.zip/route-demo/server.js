const express = require('express');

const app = express();
const PORT = 3000;

/* ===== STEP 4 - Logger Middleware ===== */
app.use((req, res, next) => {
  console.log(`${req.method} ${req.url}`);
  next();
});

/* ===== STEP 3.1 - Dynamic Route ===== */
app.get('/products/:id', (req, res) => {
  const id = req.params.id;
  res.send(`Viewing Product ID: ${id}`);
});

/* ===== STEP 3.2 - Query String ===== */
app.get('/search', (req, res) => {
  const term = req.query.q;
  res.send(`Searching for: ${term}`);
});

/* ===== Home Route ===== */
app.get('/', (req, res) => {
  res.send('Welcome to Route Handling!');
});

/* ===== STEP 5 - 404 Not Found (HARUS PALING BAWAH) ===== */
app.use((req, res) => {
  res.status(404).send("Page Not Found");
});

/* ===== Start Server ===== */
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});