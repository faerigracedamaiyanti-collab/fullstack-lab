const express = require("express");
const app = express();

// middleware JSON
app.use(express.json());

// BASE ROUTE
app.get("/", (req, res) => {
  res.send("API Online Shop is running 🚀");
});

// VERSIONING BASE (concept API)
const API_V1 = "/api/v1";

// PRODUCTS ROUTE (dummy)
app.get(`${API_V1}/products`, (req, res) => {
  res.json({
    success: true,
    message: "List of products",
  });
});

// USERS ROUTE (dummy)
app.get(`${API_V1}/users`, (req, res) => {
  res.json({
    success: true,
    message: "List of users",
  });
});

// ORDERS ROUTE (dummy)
app.get(`${API_V1}/orders`, (req, res) => {
  res.json({
    success: true,
    message: "List of orders",
  });
});

// START SERVER
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});