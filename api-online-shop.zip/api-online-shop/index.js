const express = require("express");
const app = express();

console.log("FILE TERJALAN");

app.use(express.json());

const PORT = 3000;

// 🔹 data dummy
let products = [
  { id: 1, name: "Laptop" },
  { id: 2, name: "Mouse" }
];

let orders = [];

let reviews = [
  { id: 1, productId: 1, rating: 5, comment: "Mantap!" },
  { id: 2, productId: 1, rating: 4, comment: "Bagus" }
];

// 🔹 ROOT
app.get("/", (req, res) => {
  res.send("API jalan bro 🚀");
});

// 🔹 GET PRODUCTS
app.get("/v1/products", (req, res) => {
  res.json({
    success: true,
    message: "List of products",
    data: products
  });
});

// 🔹 GET ORDERS
app.get("/v1/orders", (req, res) => {
  res.json({
    success: true,
    message: "List of orders",
    data: orders
  });
});

// 🔹 POST ORDER
app.post("/v1/orders", (req, res) => {
  const { productId, quantity, userId } = req.body;

  if (!productId || !quantity || !userId) {
    return res.status(400).json({
      success: false,
      message: "productId, quantity, dan userId wajib"
    });
  }

  if (typeof productId !== "number" || typeof quantity !== "number" || typeof userId !== "number") {
    return res.status(400).json({
      success: false,
      message: "Semua input harus angka"
    });
  }

  const product = products.find(p => p.id === productId);

  if (!product) {
    return res.status(404).json({
      success: false,
      message: "Product not found"
    });
  }

  const newOrder = {
    id: orders.length + 1,
    userId,
    productId,
    quantity
  };

  orders.push(newOrder);

  res.status(201).json({
    success: true,
    message: "Order created",
    data: newOrder
  });
});

// 🔹 DELETE ORDER
app.delete("/v1/orders/:id", (req, res) => {
  const id = parseInt(req.params.id);

  const order = orders.find(o => o.id === id);

  if (!order) {
    return res.status(404).json({
      success: false,
      message: "Order not found"
    });
  }

  orders = orders.filter(o => o.id !== id);

  res.json({
    success: true,
    message: "Order deleted"
  });
});

// 🔹 UPDATE ORDER
app.put("/v1/orders/:id", (req, res) => {
  const id = parseInt(req.params.id);
  const { quantity } = req.body;

  if (!quantity) {
    return res.status(400).json({
      success: false,
      message: "Quantity is required"
    });
  }

  const order = orders.find(o => o.id === id);

  if (!order) {
    return res.status(404).json({
      success: false,
      message: "Order not found"
    });
  }

  order.quantity = quantity;

  res.json({
    success: true,
    message: "Order updated",
    data: order
  });
});

// 🔹 STEP 4.1 → GET orders by user
app.get("/v1/users/:userId/orders", (req, res) => {
  const userId = parseInt(req.params.userId);

  const userOrders = orders.filter(o => o.userId === userId);

  res.json({
    success: true,
    message: userOrders.length ? "Orders for user" : "No orders found",
    data: userOrders
  });
});

// 🔹 STEP 4.2 → GET reviews by product
app.get("/v1/products/:productId/reviews", (req, res) => {
  const productId = parseInt(req.params.productId);

  const productReviews = reviews.filter(r => r.productId === productId);

  res.json({
    success: true,
    message: productReviews.length ? "Reviews for product" : "No reviews found",
    data: productReviews
  });
});

// 🔹 RUN SERVER
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});