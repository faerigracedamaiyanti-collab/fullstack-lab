// =======================
// STEP 2: VARIABLES
// =======================

var name = "Faeri";
let age = 20;
const country = "Indonesia";

// Display variable values
console.log("Name:", name);
console.log("Age:", age);
console.log("Country:", country);


// =======================
// STEP 3: DATA TYPES
// =======================

// Number
let ageNumber = 20;

// String
let personName = "Faeri";

// Boolean
let isStudent = true;

// Array
let hobbies = ["coding", "gaming", "reading"];

// Object
let person = {
  name: "Faeri",
  age: 20,
  country: "Indonesia"
};

// Display values
console.log("Hobbies:", hobbies);
console.log("Person Object:", person);

// Check data types (typeof)
console.log("Type of ageNumber:", typeof ageNumber);
console.log("Type of personName:", typeof personName);
console.log("Type of isStudent:", typeof isStudent);
console.log("Type of hobbies:", typeof hobbies);
console.log("Type of person:", typeof person);


// =======================
// STEP 4: OPERATORS
// =======================

// Arithmetic Operators
let a = 10;
let b = 5;

console.log("Addition:", a + b);
console.log("Subtraction:", a - b);
console.log("Multiplication:", a * b);
console.log("Division:", a / b);

// Comparison Operators
console.log("a > b:", a > b);
console.log("a < b:", a < b);
console.log("a == b:", a == b);
console.log("a != b:", a != b);

// Logical Operators
let isAdult = age >= 18;
let hasID = true;

console.log("Is Adult AND Has ID:", isAdult && hasID);
console.log("Is Adult OR Has ID:", isAdult || hasID);
console.log("NOT Is Adult:", !isAdult);