// ======================
// Step 2: Variables
// ======================

var nama = "Faeri";
let umur = 20;
const negara = "Indonesia";

console.log("Nama:", nama);
console.log("Umur:", umur);
console.log("Negara:", negara);


// ======================
// Step 3: Data Types
// ======================

let angka = 10;
let teks = "Belajar JavaScript";
let isActive = true;

let buah = ["Apel", "Jeruk", "Mangga"];

let mahasiswa = {
  nama: "Faeri",
  umur: 20,
  jurusan: "Informatika"
};

console.log(typeof angka);
console.log(typeof teks);
console.log(typeof isActive);
console.log(typeof buah);
console.log(typeof mahasiswa);

console.log("Array check:", Array.isArray(buah));


// ======================
// Step 4: Operators
// ======================

// Subtask 4.1: Arithmetic Operators
let a = 10;
let b = 5;

let tambah = a + b;
let kurang = a - b;
let kali = a * b;
let bagi = a / b;

console.log("Tambah:", tambah);
console.log("Kurang:", kurang);
console.log("Kali:", kali);
console.log("Bagi:", bagi);


// ======================
// Comparison Operators
// ======================

let x = 10;
let y = 20;

let lebihBesar = x > y;
let lebihKecil = x < y;
let samaDengan = x == y;
let tidakSama = x != y;

console.log("x > y:", lebihBesar);
console.log("x < y:", lebihKecil);
console.log("x == y:", samaDengan);
console.log("x != y:", tidakSama);


// ======================
// Logical Operators
// ======================

let punyaKTP = true;
let nilai = 85;

let lulus = nilai >= 75;
let bisaMasuk = (umur >= 17) && punyaKTP;
let alternatif = (umur < 17) || punyaKTP;

console.log("Lulus:", lulus);
console.log("Bisa Masuk:", bisaMasuk);
console.log("Alternatif:", alternatif);


// ======================
// Display ke Web
// ======================

document.getElementById("output").innerHTML =
  "<h2>Data Diri</h2>" +

  "<b>Data Diri:</b><br>" +
  "Nama: " + nama + "<br>" +
  "Umur: " + umur + "<br>" +
  "Negara: " + negara + "<br><br>" +

  "<b>Tipe Data:</b><br>" +
  "angka: " + typeof angka + "<br>" +
  "teks: " + typeof teks + "<br>" +
  "isActive: " + typeof isActive + "<br>" +
  "buah: array<br>" +
  "mahasiswa: " + typeof mahasiswa + "<br><br>" +

  "<b>Operator Aritmatika:</b><br>" +
  "Tambah: " + tambah + "<br>" +
  "Kurang: " + kurang + "<br>" +
  "Kali: " + kali + "<br>" +
  "Bagi: " + bagi + "<br><br>" +

  "<b>Operator Perbandingan:</b><br>" +
  "x > y: " + lebihBesar + "<br>" +
  "x < y: " + lebihKecil + "<br>" +
  "x == y: " + samaDengan + "<br>" +
  "x != y: " + tidakSama + "<br><br>" +

  "<b>Operator Logika:</b><br>" +
  "Lulus: " + lulus + "<br>" +
  "Bisa Masuk: " + bisaMasuk + "<br>" +
  "Alternatif: " + alternatif;