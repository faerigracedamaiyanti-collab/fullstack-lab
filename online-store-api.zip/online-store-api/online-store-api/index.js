const express = require("express");
const app = express();

const PORT = 3000;

// middleware supaya bisa baca JSON body
app.use(express.json());

// test route
app.get("/", (req, res) => {
  res.send("API is running...");
});

// route /v1
app.get("/v1", (req, res) => {
  res.send("Welcome to Online Store API 🚀");
});

// data dummy products
const products = [
  { id: 1, name: "Laptop", price: 10000 },
  { id: 2, name: "Mouse", price: 200 }
];

// GET semua produk
app.get("/v1/products", (req, res) => {
  res.json(products);
});

// GET produk by ID
app.get("/v1/products/:id", (req, res) => {
  const id = parseInt(req.params.id);
  const product = products.find(p => p.id === id);

  if (!product) {
    return res.status(404).json({ message: "Product not found" });
  }

  res.json(product);
});

/* =========================
   ORDERS
========================= */

// data dummy orders
let orders = [];

// POST /v1/orders
app.post("/v1/orders", (req, res) => {
  const { productId, quantity } = req.body;

  if (!productId || !quantity) {
    return res.status(400).json({ message: "productId & quantity required" });
  }

  const newOrder = {
    id: orders.length + 1,
    userId: 1, // sementara dummy user
    productId,
    quantity
  };

  orders.push(newOrder);

  res.status(201).json({
    message: "Order created successfully",
    order: newOrder
  });
});

// DELETE /v1/orders/:id
app.delete("/v1/orders/:id", (req, res) => {
  const id = parseInt(req.params.id);

  const index = orders.findIndex(o => o.id === id);

  if (index === -1) {
    return res.status(404).json({ message: "Order not found" });
  }

  const deleted = orders.splice(index, 1);

  res.json({
    message: "Order deleted successfully",
    order: deleted[0]
  });
});

/* =========================
   STEP 4 - NESTED ROUTES
========================= */

// dummy reviews data
let reviews = [
  { id: 1, productId: 1, comment: "Bagus banget" },
  { id: 2, productId: 1, comment: "Murah dan bagus" },
  { id: 3, productId: 2, comment: "Cukup oke" }
];

// Subtask 4.1: GET orders by user
app.get("/v1/users/:userId/orders", (req, res) => {
  const userId = parseInt(req.params.userId);

  const userOrders = orders.filter(o => o.userId === userId);

  res.json(userOrders);
});

// Subtask 4.2: GET reviews by product
app.get("/v1/products/:productId/reviews", (req, res) => {
  const productId = parseInt(req.params.productId);

  const productReviews = reviews.filter(r => r.productId === productId);

  res.json(productReviews);
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});