const button = document.getElementById("fetchBtn");
const result = document.getElementById("result");

button.addEventListener("click", fetchData);

function fetchData() {
    result.innerHTML = "Loading...";

    fetch("https://jsonplaceholder.typicode.com/users")
        .then(response => {
            if (!response.ok) {
                throw new Error("Gagal mengambil data");
            }
            return response.json();
        })
        .then(data => {
            result.innerHTML = "";

            data.forEach(user => {
                const div = document.createElement("div");
                div.classList.add("card");

                div.innerHTML = `
                    <h3>${user.name}</h3>
                    <p>Email: ${user.email}</p>
                    <p>City: ${user.address.city}</p>
                `;

                result.appendChild(div);
            });
        })
        .catch(error => {
            result.innerHTML = "Terjadi error!";
            console.log(error);
        });
}