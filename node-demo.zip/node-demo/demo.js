const fs = require('fs');

console.log("Hello, Node.js!");

// buat isi pesan (SUDAH DIUBAH)
const message = "This message has been updated and modified successfully!";

// tulis ke file message.txt
fs.writeFile('message.txt', message, (err) => {
  if (err) {
    console.log("Error writing file");
  } else {
    console.log("File created successfully!");
  }
});