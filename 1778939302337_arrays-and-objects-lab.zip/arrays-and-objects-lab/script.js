// =======================
// STEP 2: ARRAYS
// =======================

// Create Arrays
let fruits = ["Apple", "Banana", "Orange"];
let numbers = [1, 2, 3, 4, 5];
let colors = ["Red", "Blue", "Green"];

// Array Methods
fruits.push("Mango");
console.log("After push:", fruits);

fruits.pop();
console.log("After pop:", fruits);

fruits.unshift("Grape");
console.log("After unshift:", fruits);

fruits.shift();
console.log("After shift:", fruits);

console.log("Array length:", fruits.length);


// =======================
// STEP 3: OBJECTS
// =======================

let student = {
  name: "Andi",
  age: 20,
  major: "Informatics"
};

// Access
console.log("Name:", student.name);
console.log("Age:", student["age"]);

// Modify
student.age = 21;
student["major"] = "Computer Science";

console.log("Updated Student:", student);


// =======================
// STEP 4: BUILT-IN METHODS
// =======================

// map, filter, forEach
let numbers2 = [1, 2, 3, 4, 5, 6];

// map()
let doubled = numbers2.map(num => num * 2);
console.log("Doubled:", doubled);

// filter()
let evenNumbers = numbers2.filter(num => num % 2 === 0);
console.log("Even Numbers:", evenNumbers);

// forEach()
numbers2.forEach(num => {
  console.log("Number:", num);
});


// Objects inside array
let students = [
  { name: "Andi", age: 20 },
  { name: "Budi", age: 22 },
  { name: "Siti", age: 19 }
];

// map (ambil nama)
let names = students.map(s => s.name);
console.log("Student Names:", names);

// filter (umur > 20)
let above20 = students.filter(s => s.age > 20);
console.log("Age > 20:", above20);

// forEach (tampil semua)
students.forEach(s => {
  console.log(s.name + " is " + s.age + " years old");
});