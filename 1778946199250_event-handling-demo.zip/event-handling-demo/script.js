
// =======================
// DOM ACCESS
// =======================

const textInput = document.getElementById("textInput");
const btnClick = document.getElementById("btnClick");
const btnClear = document.getElementById("btnClear");
const nameInput = document.getElementById("nameInput");
const form = document.getElementById("myForm");
const output = document.getElementById("output");


// =======================
// CLICK EVENT
// =======================

btnClick.addEventListener("click", () => {
  output.textContent = "Button clicked!";
});


// =======================
// CLEAR EVENT
// =======================

btnClear.addEventListener("click", () => {
  textInput.value = "";
  nameInput.value = "";
  output.textContent = "Cleared!";
});


// =======================
// INPUT EVENT
// =======================

textInput.addEventListener("input", (e) => {
  output.textContent = `Typing: ${e.target.value}`;
});


// =======================
// CHANGE EVENT
// =======================

textInput.addEventListener("change", (e) => {
  console.log("Changed:", e.target.value);
});


// =======================
// SUBMIT EVENT
// =======================

form.addEventListener("submit", (e) => {
  e.preventDefault();
  output.textContent = `Submitted: ${nameInput.value}`;
});


// =======================
// KEYUP EVENT
// =======================

textInput.addEventListener("keyup", (e) => {
  console.log("Key pressed:", e.key);
});


// =======================
// MOUSE EVENTS
// =======================

btnClick.addEventListener("mouseover", () => {
  btnClick.style.backgroundColor = "green";
});

btnClick.addEventListener("mouseout", () => {
  btnClick.style.backgroundColor = "#3498db";
});


// =======================
// FOCUS & BLUR EVENTS
// =======================

textInput.addEventListener("focus", () => {
  textInput.style.border = "2px solid green";
});

textInput.addEventListener("blur", () => {
  textInput.style.border = "1px solid #aaa";
});