// ======================
// Step 2: Variables
// ======================
const dataDiri = {
  nama: "Faeri",
  umur: 21,
  negara: "Indonesia"
};

// ======================
// Step 5: Destructuring
// ======================
const { nama, umur, negara } = dataDiri;

// ======================
// Step 3 & 4: Arrow Function + Template Literals
// ======================

// Default parameter
const sapa = (nama = "User") => `Halo, ${nama}! 👋`;

// Destructuring + default values
const tampilData = ({
  nama = "Tidak diketahui",
  umur = 0,
  negara = "Tidak diketahui",
  status = "Belum diketahui"
} = {}) => `
  Nama: ${nama} <br>
  Umur: ${umur} <br>
  Negara: ${negara} <br>
  Status: ${status}
`;

// ======================
// Spread Operator
// ======================
const dataLengkap = {
  ...dataDiri,
  status: umur >= 18 ? "Dewasa" : "Belum Dewasa"
};

// ======================
// Output
// ======================
document.getElementById("output").innerHTML = `
  ${sapa(nama)} <br><br>
  ${tampilData(dataLengkap)}
`;