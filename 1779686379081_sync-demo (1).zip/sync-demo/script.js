// ======================
// STEP 1: SYNCHRONOUS
// ======================
console.log("=== STEP 1: SYNCHRONOUS ===");
console.log("A");
console.log("B");
console.log("C");


// ======================
// STEP 2: setTimeout (MACROTASK)
// ======================
console.log("\n=== STEP 2: setTimeout ===");

console.log("Start");

setTimeout(() => {
  console.log("Timeout");
}, 0);

console.log("End");


// ======================
// STEP 3: PROMISE (MICROTASK)
// ======================
console.log("\n=== STEP 3: PROMISE ===");

console.log("Start");

Promise.resolve().then(() => {
  console.log("Promise");
});

console.log("End");


// ======================
// STEP 4: COMBINE (MICRO vs MACRO)
// ======================
console.log("\n=== STEP 4: COMBINE ===");

console.log("Start");

setTimeout(() => {
  console.log("Timeout");
}, 0);

Promise.resolve().then(() => {
  console.log("Promise");
});

console.log("End");


// ======================
// STEP 5: ASYNC / AWAIT
// ======================
console.log("\n=== STEP 5: ASYNC/AWAIT ===");

async function test() {
  console.log("1");
  await Promise.resolve();
  console.log("2");
}

console.log("3");
test();
console.log("4");


// ======================
// STEP 6: CHALLENGE
// ======================
console.log("\n=== STEP 6: CHALLENGE ===");

console.log("A");

setTimeout(() => {
  console.log("B");
}, 0);

Promise.resolve().then(() => {
  console.log("C");
});

console.log("D");